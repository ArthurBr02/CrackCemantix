_______________________________________________________________________________

   DICTIONNAIRES ORTHOGRAPHIQUES FRANÇAIS
   versions quotidiennes
   
   Ces versions ne sont publiées que pour test et ne sont pas considérées
   comme fiables. Les fichiers n’utilisent pas la compression Hunspell.
   Il est fortement déconseillé de les inclure dans les sources de vos
   logiciels.

   Olivier R. - dicollecte<at>free<dot>fr
   Dicollecte: http://www.dicollecte.org/

   Licences :
   * MPL : Mozilla Public License
     version 1.1 ou supérieure  --  http://www.mozilla.org/MPL/MPL-1.1.html
   * GPL : GNU General Public License
     version 2.0 ou supérieure  --  http://www.gnu.org/licenses/gpl-2.0.html
   * LGPL : GNU Lesser General Public License
     version 2.1 ou supérieure  --  http://www.gnu.org/licenses/lgpl-2.1.html

_______________________________________________________________________________

   FRENCH SPELLING DICTIONARIES
   daily builds
   
   These versions are published only for testing and not considered reliable.
   The files do not use the Hunspell compression.
   It is strongly unadvised to include these files in the sources of your
   softwares.

   Olivier R. - dicollecte<at>free<dot>fr
   Dicollecte: http://www.dicollecte.org/

   Licenses :
   * MPL : Mozilla Public License
     version 1.1 or higher  --  http://www.mozilla.org/MPL/MPL-1.1.html
   * GPL : GNU General Public License
     version 2.0 or higher  --  http://www.gnu.org/licenses/gpl-2.0.html
   * LGPL : GNU Lesser General Public License
     version 2.1 or higher  --  http://www.gnu.org/licenses/lgpl-2.1.html

_______________________________________________________________________________